# jade
![the plant logo](extras/jade-logo.png)

## Features
- Lightweight and fast
- Easy to learn and use
- Supports HTML5 and CSS3
- Extensible and customizable
- Supports modular design
- Supports component-based architecture
