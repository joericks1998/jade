from . import compiler
import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python readfile.py <filename>")
        sys.exit(1)

    filename = sys.argv[1]

    try:
        compiler.compile(filename)
    except FileNotFoundError:
        print(f"File not found: {filename}")
    except Exception as e:
        print(f"Error reading file: {e}")


if __name__ == "__main__":
    main()
